package egovframework.com.admin.service.impl;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;
import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

@Repository("AdminDAO")
public class AdminDAO extends EgovAbstractMapper{
	
	// 로그인
	public HashMap<String, Object> selectLoginInfo(HashMap<String, Object> paramMap){
		return selectOne("selectLoginInfo", paramMap);
	}
	
	// 목록
	public List<HashMap<String, Object>> selectBoardList(HashMap<String, Object> paramMap){
		return selectList("selectBoardList", paramMap);
	}
	
	// 목록 페이지
	public int selectBoardListCnt(HashMap<String, Object> paramMap) {
		return selectOne("selectBoardListCnt", paramMap);
	}
	
	// 등록
	public int insertBoard(HashMap<String, Object> paramMap) {
		return insert("insertBoard", paramMap);
	}
	
	// 수정
	public int updateBoard(HashMap<String, Object> paramMap) {
		return update("updateBoard", paramMap);
	}
	
	// 상세
//	public HashMap<String, Object> selectBoardDetail(int eventSeq){
//		return selectOne("selectBoardDetail", eventSeq);
//	}
	public HashMap<String, Object> getAdminEventInfo(HashMap<String, Object> paramMap){
		return selectOne("selectAdminEventInfo", paramMap);
	}
	
	// 삭제
	public int deleteBoard(HashMap<String, Object> paramMap) {
		return update("deleteBoard", paramMap);
	}
	
	// 파일 
	public int getFileGroupMaxIdx() {
		return selectOne("getFileGroupMaxIdx");
	}
	
	public int getFileGroupIdx(HashMap<String, Object> paramMap) {
		return selectOne("getFileGroupIdx", paramMap);
	}
	
	public int insertFileAttr(HashMap<String, Object> paramMap) {
		return insert("insertFileAttr", paramMap);
	}
	
	// 기존 파일
//	public List<HashMap<String, Object>> selectFileList(int fileGroupIdx){
//		return selectList("selectFileList", fileGroupIdx);
//	}
	public List<HashMap<String, Object>> selectFileList(HashMap<String, Object> paramMap){
		return selectList("selectFileList", paramMap);
	}
	
	
	// 파일 삭제
	public int deleteFileAttr(HashMap<String, Object> paramMap) {
		return update("deleteFileAttr", paramMap);
	}
	
	// 접수 목록
	public List<HashMap<String, Object>> selectEventApplyList(HashMap<String, Object> paramMap){
		return selectList("selectEventApplyList", paramMap);
	}
	
	// 접수 확인
	public int setEventJoinCofirm(HashMap<String, Object> paramMap) {
		return update("setEventJoinCofirm", paramMap);
	}
	
	
}
