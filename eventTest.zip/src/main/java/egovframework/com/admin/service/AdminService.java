package egovframework.com.admin.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public interface AdminService {

	//	로그인
	public HashMap<String, Object> selectLoginInfo(HashMap<String, Object> paramMap);
	
	//	목록
	public List<HashMap<String, Object>> selectBoardList(HashMap<String, Object> paramMap);
	
	//	목록 페이지
	public int selectBoardListCnt(HashMap<String, Object> paramMap);
	
	//	저장
	public int saveBoard(HashMap<String, Object> paramMap, List<MultipartFile> multipartFile);
	
	// 게시물 상세화면
	HashMap<String, Object> getAdminEventInfo(HashMap<String, Object> paramMap);
	//public HashMap<String, Object> selectBoardDetail(int eventSeq);
	
	//	게시물 삭제
	public int deleteBoard(HashMap<String, Object> paramMap);
	
	// 파일
	// public List<HashMap<String, Object>> selectFileList(int fileGroupIdx);
	List<HashMap<String, Object>> selectFileList(HashMap<String, Object> paramMap);
	
	
	//	접수 목록
	List<HashMap<String, Object>> selectEventApplyList(HashMap<String, Object> paramMap);
	
	//	접수 확인
	int setEventJoinCofirm(HashMap<String, Object> paramMap);



}
